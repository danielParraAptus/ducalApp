var app = angular.module('starter.controllers', []);

  app.controller('MenuCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          $scope.fechaActual = new Date();
          $scope.fechaFin = new Date(2017, 06, 22, 24);
      });
  });

//////////////////////////////    EVENTOS     /////////////////////

  app.controller('EventosCtrl', function($scope, $state, $ionicPopup, Peticiones) {
        $scope.$on('$ionicView.enter', function(){
            recogerEventos();
        });

        function recogerEventos(){
            $.when(Peticiones.GetEventos()).done(function(data, data2, data3){
                var otro = data3.responseXML;
                var array = otro.getElementsByTagName('item');

                console.log(array);
                var arrayEventos = [];

                for(i = 0; i < array.length ; i++){
                    console.log('Entro en el for: ' + i);
                    var objetoEventos = [];
                    var eventoId = array[i].getElementsByTagName('event_id')[0].childNodes[0].nodeValue;
                    var eventoName = array[i].getElementsByTagName('event_name')[0].innerHTML;
                    var eventoStartTime = array[i].getElementsByTagName('event_start_time')[0].innerHTML;
                    var eventoEndTime = array[i].getElementsByTagName('event_end_time')[0].innerHTML;
                    var eventoStartDate = array[i].getElementsByTagName('event_start_date')[0].innerHTML;
                    var eventoEndDate = array[i].getElementsByTagName('event_end_date')[0].innerHTML;
                    var eventoContenido = array[i].getElementsByTagName('post_content')[0].innerHTML;
                    var direccionLongitud = array[i].getElementsByTagName('location_longitude')[0].innerHTML;
                    var direccionLatitud = array[i].getElementsByTagName('location_latitude')[0].innerHTML;
                    var guid = array[i].getElementsByTagName('guid')[0].innerHTML;

                    objetoEventos.eventoId = eventoId;
                    objetoEventos.eventoName = eventoName;
                    objetoEventos.eventoStartTime = eventoStartTime;
                    objetoEventos.eventoEndTime = eventoEndTime;
                    objetoEventos.eventoStartDate = eventoStartDate;
                    objetoEventos.eventoEndDate = eventoEndDate;
                    objetoEventos.eventoContenido = eventoContenido;
                    objetoEventos.direccionLongitud = direccionLongitud;
                    objetoEventos.direccionLatitud = direccionLatitud;
                    objetoEventos.guid = guid;

                    arrayEventos.push(objetoEventos);
                }

                $scope.datos = arrayEventos;

            })
        }

        $scope.verEvento = function(id) {
            console.log('El id es: ' + id);
            localStorage.setItem('idEvento', id);
            $state.go('eventos-vista');
        }

  });

  //////////////////////////////    EVENTOS-VISTA     /////////////////////

  app.controller('EventosVistaCtrl', function($scope, $state, $ionicPopup, Peticiones) {
        $scope.$on('$ionicView.enter', function(){
            var id = localStorage.getItem('idEvento');
            //localStorage.removeItem('idEvento');
            console.log('El id es: ' + id);
            recogerEventosPorId(id);
        });

      function recogerEventosPorId(idEvento){
          $.when(Peticiones.GetEventosById(idEvento)).done(function(devuelto, data , data2){
                console.log(data2);
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('return');
                var objetoEventos = [];

                for(i = 0; i < array.length ; i++){
                    console.log('Entro en el for ' + i);
                    var eventoId = array[i].getElementsByTagName('event_id')[0].childNodes[0].nodeValue;
                    var eventoName = array[i].getElementsByTagName('event_name')[0].innerHTML;
                    var eventoStartTime = array[i].getElementsByTagName('event_start_time')[0].innerHTML;
                    var eventoEndTime = array[i].getElementsByTagName('event_end_time')[0].innerHTML;
                    var eventoStartDate = array[i].getElementsByTagName('event_start_date')[0].innerHTML;
                    var eventoEndDate = array[i].getElementsByTagName('event_end_date')[0].innerHTML;
                    var eventoContenido = array[i].getElementsByTagName('post_content')[0].innerHTML;
                    var direccionLongitud = array[i].getElementsByTagName('location_longitude')[0].innerHTML;
                    var direccionLatitud = array[i].getElementsByTagName('location_latitude')[0].innerHTML;
                    console.log('Contenido: ' + eventoContenido);
                    console.log('direccionLongitud: ' + direccionLongitud);
                    console.log('direccionLatitud: ' + direccionLatitud);

                    objetoEventos.eventoId = eventoId;
                    objetoEventos.eventoName = eventoName;
                    objetoEventos.eventoStartTime = eventoStartTime;
                    objetoEventos.eventoEndTime = eventoEndTime;
                    objetoEventos.eventoStartDate = eventoStartDate;
                    objetoEventos.eventoEndDate = eventoEndDate;
                    objetoEventos.eventoContenido = eventoContenido;
                    objetoEventos.direccionLongitud = direccionLongitud;
                    objetoEventos.direccionLatitud = direccionLatitud;
                    objetoEventos.direccionMaps = 'http://google.com/maps/place/' + direccionLongitud + ',' + direccionLatitud + '&z=23z';

                    $scope.datos = objetoEventos;
                }

                
            })
        }

  });

  //////////////////////////////    CALENDARIO     /////////////////////

  app.controller('CalendarioCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          
      });

  });

   //////////////////////////////    FORUM     /////////////////////

  app.controller('ForumCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          
      });

  });

  //////////////////////////////    Sesiones Llegar     /////////////////////

  app.controller('SesionesLlegarCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarComoLlegar();
      });

       function mostrarComoLlegar() {
          $.when(Peticiones.GetComoLlegar()).done(function(devuelto, data , data2){
                console.log(data2);
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var objetoEventos = [];

                for(i = 0; i < array.length ; i++){
                    console.log('Entro en el for ' + i);
                    var menuTitulo = array[i].getElementsByTagName('menu_titulo')[0].childNodes[0].nodeValue;
                    var menuEnlace = array[i].getElementsByTagName('menu_enlace')[0].innerHTML;

                    objetoEventos.menuTitulo = menuTitulo;
                    objetoEventos.menuEnlace = menuEnlace;

                    $scope.datos = objetoEventos;
                }

          })
       }

  });

  //////////////////////////////    Sesiones Fotos     /////////////////////

  app.controller('SesionesFotosCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarFotos();
      });

       function mostrarFotos() {
          $.when(Peticiones.GetFotos()).done(function(devuelto, data , data2){
                console.log(data2);
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var arrayFotos = [];

                for(i = 0; i < array.length ; i++){
                    var objetoFotos = [];
                    console.log('Entro en el for ' + i);
                    var hrefHref = array[i].getElementsByTagName('href_href')[0].childNodes[0].nodeValue;
                    var hrefTexto = array[i].getElementsByTagName('href_texto')[0].innerHTML;
                    console.log('Href: ' + hrefHref);
                    console.log('Texto: ' + hrefTexto);

                    objetoFotos.hrefHref = hrefHref;
                    objetoFotos.hrefTexto = hrefTexto;

                    arrayFotos.push(objetoFotos);
                }

                $scope.datos = arrayFotos;

          })
       }

  });

  //////////////////////////////    Sesiones Agenda     /////////////////////

  app.controller('SesionesAgendaCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarAgenda();
      });

       function mostrarAgenda() {
          $.when(Peticiones.GetAgenda()).done(function(devuelto, data , data2){
                console.log(data2);
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var arrayFotos = [];

                for(i = 0; i < array.length ; i++){
                    var objetoFotos = [];
                    console.log('Entro en el for ' + i);
                    var menuTitulo = array[i].getElementsByTagName('menu_titulo')[0].childNodes[0].nodeValue;
                    var menuEnlace = array[i].getElementsByTagName('menu_enlace')[0].innerHTML;

                    objetoFotos.menuTitulo = menuTitulo;
                    objetoFotos.menuEnlace = menuEnlace;

                    arrayFotos.push(objetoFotos);
                }

                $scope.datos = arrayFotos;

          })
       }

  });

  //////////////////////////////    SESIONES MAGISTRALES     /////////////////////

  app.controller('SesionesMagistralesCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarMagistrales();
      });

      function mostrarMagistrales() {
          $.when(Peticiones.GetSessionsMagistrales()).done(function(devuelto, data , data2){
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var arraySesiones = [];

                for(i = 0; i < array.length ; i++){
                    var objetoSesiones = [];
                    console.log('Entro en el for ' + i);
                    var semaId = array[i].getElementsByTagName('sema_id')[0].childNodes[0].nodeValue;
                    var semaImagen = array[i].getElementsByTagName('sema_imagen')[0].innerHTML;
                    var semaUrl = array[i].getElementsByTagName('sema_url')[0].innerHTML;
                    var semaTitulo = array[i].getElementsByTagName('sema_titulo')[0].innerHTML;
                    var semaAutor = array[i].getElementsByTagName('sema_autor')[0].innerHTML;
                    var semaProfesion = array[i].getElementsByTagName('sema_profesion')[0].innerHTML;
                    var semaFrase = array[i].getElementsByTagName('sema_frase')[0].innerHTML;
                    var semaPeso = array[i].getElementsByTagName('sema_peso')[0].innerHTML;

                    objetoSesiones.semaId = semaId;
                    objetoSesiones.semaImagen = semaImagen;
                    objetoSesiones.semaUrl = semaUrl;
                    objetoSesiones.semaTitulo = semaTitulo;
                    objetoSesiones.semaAutor = semaAutor;
                    objetoSesiones.semaProfesion = semaProfesion;
                    objetoSesiones.semaFrase = semaFrase;
                    objetoSesiones.semaPeso = semaPeso;

                    arraySesiones.push(objetoSesiones);
                }

                $scope.datos = arraySesiones;
          })
      }

  });

  //////////////////////////////    SESIONES PARALELAS     /////////////////////

  app.controller('SesionesParalelasCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarParalelas();
      });

      function mostrarParalelas() {
          $.when(Peticiones.GetSessionsByType(3)).done(function(devuelto, data , data2){
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');

                var fechaAnterior = "";
                var horaAnterior = "";
                var idAnterior = "";
                 
                var arrayCalendario = [];
                var arrayHoras = [];
                var arraySesiones = [];

                if(array.length == 0){
                    $scope.noData = 'No hay datos de Sesiones Paralelas.'
                }

                for(i = 0; i < array.length ; i++){
                    var objetoSesiones = [];
                    var objetoHora = [];
                    var objetoCalendario = [];
                    var sesiId = array[i].getElementsByTagName('sesi_id')[0].childNodes[0].nodeValue;
                    var sesiDiaIni = array[i].getElementsByTagName('sesi_dia_inicio')[0].innerHTML;
                    var sesiDiaFin = array[i].getElementsByTagName('sesi_dia_fin')[0].innerHTML;
                    var sesiImagen = array[i].getElementsByTagName('sesi_imagen')[0].innerHTML;
                    var sesiEmpresa = array[i].getElementsByTagName('sesi_empresa')[0].innerHTML;
                    var sesiResumen = array[i].getElementsByTagName('sesi_resumen')[0].innerHTML;
                    var sesiPeso = array[i].getElementsByTagName('sesi_peso')[0].innerHTML;

                    var dateActual = new Date(sesiDiaIni);

                    var fechaActual = dateActual.getDate() + '/' + dateActual.getMonth() + '/' + dateActual.getFullYear();

                    if(dateActual.getMinutes() == 0){
                        var horaActual = dateActual.getHours() + ':0' + dateActual.getMinutes();
                    }else{
                        var horaActual = dateActual.getHours() + ':' + dateActual.getMinutes();
                    }

                    var contador = i;
                    var contador1 = array.length - 1;
                    console.log('----------------------------------------------------');
                    console.log('Empresa: ' + sesiEmpresa); 
                    console.log('Fecha actual: ' + fechaActual); 
                    console.log('Hora actual: ' + horaActual); 
                    console.log('Hora actual: ' + (i == (array.length-1)) );


                    objetoSesiones.sesiId = sesiId;
                    objetoSesiones.sesiDiaIni = sesiDiaIni;
                    objetoSesiones.sesiDiaFin = sesiDiaFin;
                    objetoSesiones.sesiImagen = sesiImagen;
                    objetoSesiones.sesiEmpresa = sesiEmpresa;
                    objetoSesiones.sesiResumen = sesiResumen;
                    objetoSesiones.sesiPeso = sesiPeso;
                    objetoSesiones.idAnterior = idAnterior;

                    if((horaActual != horaAnterior || fechaActual != fechaAnterior || (i == (array.length-1)) ) && i != 0){
                        if(i == (array.length-1)){
                            arraySesiones.push(objetoSesiones);
                        }
                        console.log('Entro en la hora');
                        objetoHora.hora = horaAnterior;
                        objetoHora.sesiones = arraySesiones;  
                        arraySesiones = [];

                        arrayHoras.push(objetoHora);
                    }

                    arraySesiones.push(objetoSesiones);

                    if(fechaActual != fechaAnterior || (i == (array.length-1)) ){
                        console.log('Entro en la fecha');
                        objetoCalendario.fecha = fechaAnterior;
                        objetoCalendario.horas = arrayHoras;
                        arrayHoras = [];

                        arrayCalendario.push(objetoCalendario);
                    }

                    fechaAnterior = fechaActual;
                    horaAnterior = horaActual;
                    idAnterior = sesiId;

                }

                $scope.datos = arrayCalendario;
          })
      }

  });

  //////////////////////////////    SESIONES DEMO     /////////////////////

  app.controller('SesionesDemoCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarDemo();
      });

      function mostrarDemo() {
          $.when(Peticiones.GetSessionsByType(1)).done(function(devuelto, data , data2){
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var fechaAnterior = "";
                var horaAnterior = "";
                var idAnterior = "";
                 
                var arrayCalendario = [];
                var arrayHoras = [];
                var arraySesiones = [];

                if(array.length == 0){
                    $scope.noData = 'No hay datos de Sesiones Paralelas.'
                }

                for(i = 0; i < array.length ; i++){
                    var objetoSesiones = [];
                    var objetoHora = [];
                    var objetoCalendario = [];
                    var sesiId = array[i].getElementsByTagName('sesi_id')[0].childNodes[0].nodeValue;
                    var sesiDiaIni = array[i].getElementsByTagName('sesi_dia_inicio')[0].innerHTML;
                    var sesiDiaFin = array[i].getElementsByTagName('sesi_dia_fin')[0].innerHTML;
                    var sesiImagen = array[i].getElementsByTagName('sesi_imagen')[0].innerHTML;
                    var sesiEmpresa = array[i].getElementsByTagName('sesi_empresa')[0].innerHTML;
                    var sesiResumen = array[i].getElementsByTagName('sesi_resumen')[0].innerHTML;
                    var sesiPeso = array[i].getElementsByTagName('sesi_peso')[0].innerHTML;

                    var dateActual = new Date(sesiDiaIni);

                    var fechaActual = dateActual.getDate() + '/' + dateActual.getMonth() + '/' + dateActual.getFullYear();

                    if(dateActual.getMinutes() == 0){
                        var horaActual = dateActual.getHours() + ':0' + dateActual.getMinutes();
                    }else{
                        var horaActual = dateActual.getHours() + ':' + dateActual.getMinutes();
                    }

                    var contador = i;
                    var contador1 = array.length - 1;
                    console.log('----------------------------------------------------');
                    console.log('Empresa: ' + sesiEmpresa); 
                    console.log('Fecha actual: ' + fechaActual); 
                    console.log('Hora actual: ' + horaActual); 
                    console.log('Hora actual: ' + (i == (array.length-1)) );


                    objetoSesiones.sesiId = sesiId;
                    objetoSesiones.sesiDiaIni = sesiDiaIni;
                    objetoSesiones.sesiDiaFin = sesiDiaFin;
                    objetoSesiones.sesiImagen = sesiImagen;
                    objetoSesiones.sesiEmpresa = sesiEmpresa;
                    objetoSesiones.sesiResumen = sesiResumen;
                    objetoSesiones.sesiPeso = sesiPeso;
                    objetoSesiones.idAnterior = idAnterior;

                    if((horaActual != horaAnterior || fechaActual != fechaAnterior || (i == (array.length-1)) ) && i != 0){
                        if(i == (array.length-1)){
                            arraySesiones.push(objetoSesiones);
                        }
                        console.log('Entro en la hora');
                        objetoHora.hora = horaAnterior;
                        objetoHora.sesiones = arraySesiones;  
                        arraySesiones = [];

                        arrayHoras.push(objetoHora);
                    }

                    arraySesiones.push(objetoSesiones);

                    if(fechaActual != fechaAnterior || (i == (array.length-1)) ){
                        console.log('Entro en la fecha');
                        objetoCalendario.fecha = fechaAnterior;
                        objetoCalendario.horas = arrayHoras;
                        arrayHoras = [];

                        arrayCalendario.push(objetoCalendario);
                    }

                    fechaAnterior = fechaActual;
                    horaAnterior = horaActual;
                    idAnterior = sesiId;

                }

                $scope.datos = arrayCalendario;
          })
      }

  });

  //////////////////////////////    SESIONES SAP     /////////////////////

  app.controller('SesionesSapCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarSap();
      });

      function mostrarSap() {
          $.when(Peticiones.GetSessionsByType(4)).done(function(devuelto, data , data2){
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var fechaAnterior = "";
                var horaAnterior = "";
                var idAnterior = "";
                 
                var arrayCalendario = [];
                var arrayHoras = [];
                var arraySesiones = [];

                if(array.length == 0){
                    $scope.noData = 'No hay datos de Sesiones Paralelas.'
                }

                for(i = 0; i < array.length ; i++){
                    var objetoSesiones = [];
                    var objetoHora = [];
                    var objetoCalendario = [];
                    var sesiId = array[i].getElementsByTagName('sesi_id')[0].childNodes[0].nodeValue;
                    var sesiDiaIni = array[i].getElementsByTagName('sesi_dia_inicio')[0].innerHTML;
                    var sesiDiaFin = array[i].getElementsByTagName('sesi_dia_fin')[0].innerHTML;
                    var sesiImagen = array[i].getElementsByTagName('sesi_imagen')[0].innerHTML;
                    var sesiEmpresa = array[i].getElementsByTagName('sesi_empresa')[0].innerHTML;
                    var sesiResumen = array[i].getElementsByTagName('sesi_resumen')[0].innerHTML;
                    var sesiPeso = array[i].getElementsByTagName('sesi_peso')[0].innerHTML;

                    var dateActual = new Date(sesiDiaIni);

                    var fechaActual = dateActual.getDate() + '/' + dateActual.getMonth() + '/' + dateActual.getFullYear();

                    if(dateActual.getMinutes() == 0){
                        var horaActual = dateActual.getHours() + ':0' + dateActual.getMinutes();
                    }else{
                        var horaActual = dateActual.getHours() + ':' + dateActual.getMinutes();
                    }

                    var contador = i;
                    var contador1 = array.length - 1;
                    console.log('----------------------------------------------------');
                    console.log('Empresa: ' + sesiEmpresa); 
                    console.log('Fecha actual: ' + fechaActual); 
                    console.log('Hora actual: ' + horaActual); 
                    console.log('Hora actual: ' + (i == (array.length-1)) );


                    objetoSesiones.sesiId = sesiId;
                    objetoSesiones.sesiDiaIni = sesiDiaIni;
                    objetoSesiones.sesiDiaFin = sesiDiaFin;
                    objetoSesiones.sesiImagen = sesiImagen;
                    objetoSesiones.sesiEmpresa = sesiEmpresa;
                    objetoSesiones.sesiResumen = sesiResumen;
                    objetoSesiones.sesiPeso = sesiPeso;
                    objetoSesiones.idAnterior = idAnterior;

                    if((horaActual != horaAnterior || fechaActual != fechaAnterior || (i == (array.length-1)) ) && i != 0){
                        if(i == (array.length-1)){
                            arraySesiones.push(objetoSesiones);
                        }
                        console.log('Entro en la hora');
                        objetoHora.hora = horaAnterior;
                        objetoHora.sesiones = arraySesiones;  
                        arraySesiones = [];

                        arrayHoras.push(objetoHora);
                    }

                    arraySesiones.push(objetoSesiones);

                    if(fechaActual != fechaAnterior || (i == (array.length-1)) ){
                        console.log('Entro en la fecha');
                        objetoCalendario.fecha = fechaAnterior;
                        objetoCalendario.horas = arrayHoras;
                        arrayHoras = [];

                        arrayCalendario.push(objetoCalendario);
                    }

                    fechaAnterior = fechaActual;
                    horaAnterior = horaActual;
                    idAnterior = sesiId;

                }

                $scope.datos = arrayCalendario;
          })
      }

  });

  //////////////////////////////    FORUM EMPLEO     /////////////////////

  app.controller('SesionesEmpleoCtrl', function($scope, $state, $ionicPopup, Peticiones) {
      $scope.$on('$ionicView.enter', function(){
          mostrarEmpleo();
      });

      function mostrarEmpleo() {
          $.when(Peticiones.GetSessionsByType(2)).done(function(devuelto, data , data2){
                var otro = data2.responseText;
                var parser = new DOMParser();
                var xml = parser.parseFromString(otro, 'text/xml');
                var array = xml.getElementsByTagName('item');
                var fechaAnterior = "";
                var horaAnterior = "";
                var idAnterior = "";
                 
                var arrayCalendario = [];
                var arrayHoras = [];
                var arraySesiones = [];

                if(array.length == 0){
                    $scope.noData = 'No hay datos de Sesiones Paralelas.'
                }

                for(i = 0; i < array.length ; i++){
                    var objetoSesiones = [];
                    var objetoHora = [];
                    var objetoCalendario = [];
                    var sesiId = array[i].getElementsByTagName('sesi_id')[0].childNodes[0].nodeValue;
                    var sesiDiaIni = array[i].getElementsByTagName('sesi_dia_inicio')[0].innerHTML;
                    var sesiDiaFin = array[i].getElementsByTagName('sesi_dia_fin')[0].innerHTML;
                    var sesiImagen = array[i].getElementsByTagName('sesi_imagen')[0].innerHTML;
                    var sesiEmpresa = array[i].getElementsByTagName('sesi_empresa')[0].innerHTML;
                    var sesiResumen = array[i].getElementsByTagName('sesi_resumen')[0].innerHTML;
                    var sesiPeso = array[i].getElementsByTagName('sesi_peso')[0].innerHTML;

                    var dateActual = new Date(sesiDiaIni);

                    var fechaActual = dateActual.getDate() + '/' + dateActual.getMonth() + '/' + dateActual.getFullYear();

                    if(dateActual.getMinutes() == 0){
                        var horaActual = dateActual.getHours() + ':0' + dateActual.getMinutes();
                    }else{
                        var horaActual = dateActual.getHours() + ':' + dateActual.getMinutes();
                    }

                    var contador = i;
                    var contador1 = array.length - 1;
                    console.log('----------------------------------------------------');
                    console.log('Empresa: ' + sesiEmpresa); 
                    console.log('Fecha actual: ' + fechaActual); 
                    console.log('Hora actual: ' + horaActual); 
                    console.log('Hora actual: ' + (i == (array.length-1)) );


                    objetoSesiones.sesiId = sesiId;
                    objetoSesiones.sesiDiaIni = sesiDiaIni;
                    objetoSesiones.sesiDiaFin = sesiDiaFin;
                    objetoSesiones.sesiImagen = sesiImagen;
                    objetoSesiones.sesiEmpresa = sesiEmpresa;
                    objetoSesiones.sesiResumen = sesiResumen;
                    objetoSesiones.sesiPeso = sesiPeso;
                    objetoSesiones.idAnterior = idAnterior;

                    if((horaActual != horaAnterior || fechaActual != fechaAnterior || (i == (array.length-1)) ) && i != 0){
                        if(i == (array.length-1)){
                            arraySesiones.push(objetoSesiones);
                        }
                        console.log('Entro en la hora');
                        objetoHora.hora = horaAnterior;
                        objetoHora.sesiones = arraySesiones;  
                        arraySesiones = [];

                        arrayHoras.push(objetoHora);
                    }

                    arraySesiones.push(objetoSesiones);

                    if(fechaActual != fechaAnterior || (i == (array.length-1)) ){
                        console.log('Entro en la fecha');
                        objetoCalendario.fecha = fechaAnterior;
                        objetoCalendario.horas = arrayHoras;
                        arrayHoras = [];

                        arrayCalendario.push(objetoCalendario);
                    }

                    fechaAnterior = fechaActual;
                    horaAnterior = horaActual;
                    idAnterior = sesiId;

                }

                $scope.datos = arrayCalendario;
          })
      }

  });
  ///////// FIN //////////


